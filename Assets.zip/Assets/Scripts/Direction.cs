﻿public enum Direction
{
	Stop,
	Left,
	Right,
	Top,
	Down,

	count = 5 
}