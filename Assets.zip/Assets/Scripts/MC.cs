﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MC : MonoBehaviour {

	public GameObject alertUI;
	public GameObject playerOne;
	public GameObject playerTwo;
	public GameObject playerWin;
	public List<UndercoverCop> cops;
}
